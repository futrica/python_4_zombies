ano = int(input ("entre com um ano: "))

if (ano % 4 == 0):
    print("bissexto")
else:
    print ("não é bissexto")
